import React, { useState } from 'react';
import { Star, ChevronDown, ChevronUp, Quote, MessageCircle, HelpCircle } from 'lucide-react';
import { FAQS } from '../data/hotelData';

interface GuestReviewsAndFAQProps {
  onOpenBooking: () => void;
}

const REVIEWS = [
  {
    name: 'Arjun & Neha M.',
    origin: 'Bengaluru, Karnataka',
    trip: 'Athirappilly Road Trip · Couple',
    text: 'We were looking for a clean, affordable place to rest during our weekend trip to Athirappilly Waterfalls. Crown Tourist Home was exactly what we needed! Crisp, clean bed sheets, clean bathroom, and the manager was kind enough to let us check in a bit early after our long drive. Plus, Vasuettans Kada lunch nearby was heavenly!',
  },
  {
    name: 'Sreejith K.',
    origin: 'Kozhikode, Kerala',
    trip: 'Biker & Nature Explorer',
    text: 'Safe bike parking directly in front of the building under CCTV, decent comfortable bed, and a fast ceiling fan. At ₹700-800, you cannot ask for a better honest tourist home on the highway. Highly recommend for bikers heading to Valparai via Athirappilly.',
  },
  {
    name: 'Deepak Varghese',
    origin: 'Ernakulam, Kerala',
    trip: 'Family Visit to Dream World & Waterfalls',
    text: 'Visited Dream World Water Park with kids and stayed here overnight. Clean rooms, no unwanted hotel fees, and transparent manager. We paid through Google Pay on arrival. Simple and genuine.',
  },
];

export const GuestReviewsAndFAQ: React.FC<GuestReviewsAndFAQProps> = ({ onOpenBooking }) => {
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  const toggleFaq = (idx: number) => {
    setOpenFaqIndex(openFaqIndex === idx ? null : idx);
  };

  return (
    <section className="py-16 lg:py-24 bg-[#FAF8F5] border-t border-[#E6E0D4]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Testimonials */}
        <div className="mb-20">
          <div className="max-w-3xl mb-12">
            <div className="text-xs font-semibold tracking-wider uppercase text-[#7A5835] mb-2">
              Guest Feedback · Real Travelers
            </div>
            <h2 className="font-editorial text-3xl sm:text-4xl lg:text-5xl font-semibold text-[#1F1E1B] text-balance">
              What travelers say about their stay.
            </h2>
            <p className="mt-3 text-base text-[#5C5449] leading-relaxed">
              No sponsored influencers or marketing buzzwords. Just honest reviews from road trippers, families, and backpackers who stayed with us.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {REVIEWS.map((review, idx) => (
              <div
                key={idx}
                className="bg-white rounded-2xl border border-[#E3DBD0] p-6 shadow-sm flex flex-col justify-between"
              >
                <div>
                  {/* Clean unboxed proof score */}
                  <div className="flex items-center gap-1 text-[#C48729] mb-4">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-current" />
                    ))}
                    <span className="text-xs font-semibold text-[#3C362F] ml-1.5">
                      5.0
                    </span>
                  </div>

                  <p className="text-xs sm:text-sm text-[#4A4237] leading-relaxed italic">
                    "{review.text}"
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-[#F2EDE3]">
                  <p className="text-xs font-semibold text-[#1F1E1B]">
                    {review.name}
                  </p>
                  <p className="text-[11px] text-[#7A5835]">
                    {review.origin} · {review.trip}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* FAQ Section */}
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-10">
            <div className="text-xs font-semibold tracking-wider uppercase text-[#7A5835] mb-2">
              Common Questions
            </div>
            <h2 className="font-editorial text-3xl sm:text-4xl font-semibold text-[#1F1E1B]">
              Frequently Asked Questions
            </h2>
            <p className="mt-2 text-sm text-[#5C5449]">
              Everything you need to know about staying at Crown Tourist Home.
            </p>
          </div>

          <div className="space-y-3">
            {FAQS.map((faq, idx) => {
              const isOpen = openFaqIndex === idx;
              return (
                <div
                  key={idx}
                  className="bg-white rounded-xl border border-[#E3DBD0] overflow-hidden shadow-sm"
                >
                  <button
                    onClick={() => toggleFaq(idx)}
                    className="w-full px-5 py-4 text-left flex items-center justify-between gap-4 hover:bg-[#FAF8F5] transition-colors"
                  >
                    <span className="text-sm font-semibold text-[#1F1E1B]">
                      {faq.q}
                    </span>
                    <span className="text-[#7A5835] shrink-0">
                      {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </span>
                  </button>

                  {isOpen && (
                    <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-[#524B41] leading-relaxed border-t border-[#F5F0E8] bg-[#FDFBF7]">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Quick CTA inside FAQ */}
          <div className="mt-10 p-6 bg-[#2D4A3E] rounded-2xl text-white text-center sm:flex sm:items-center sm:justify-between sm:text-left gap-6">
            <div>
              <h3 className="font-editorial text-2xl font-semibold">
                Have a specific question or traveling today?
              </h3>
              <p className="text-xs text-white/80 mt-1">
                Our manager is ready to confirm room status and assist with routes.
              </p>
            </div>
            <button
              onClick={onOpenBooking}
              className="mt-4 sm:mt-0 w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-3 text-xs font-semibold bg-white text-[#2D4A3E] hover:bg-[#FAF8F5] rounded-xl shadow-sm transition-colors shrink-0 min-h-[44px]"
            >
              <MessageCircle className="w-4 h-4 text-[#2D4A3E]" />
              <span>Message Manager on WhatsApp</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
