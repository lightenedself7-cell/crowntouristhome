export interface HeroSlide {
  id: string;
  url: string;
  title: string;
  caption: string;
  tag: string;
}

export const HERO_SLIDES: HeroSlide[] = [
  {
    id: 'entrance-day',
    url: '/assets/aistudio/Crown_Tourist_Home_Entrance_725f6b0e.png',
    title: 'Main Entrance & Front Parking',
    caption: 'Poovathingal, Pariyaram · Athirappilly Route',
    tag: 'Day View · Direct Highway Access',
  },
  {
    id: 'entrance-dusk',
    url: '/assets/aistudio/Crown_Tourist_Home_at_Dusk_77e290a6.png',
    title: 'Exterior View at Dusk & 24/7 Access',
    caption: 'Chalakudy - Anamala Road · Poovathingal',
    tag: 'Dusk View · Well-Lit Parking & 24/7 Security',
  },
];

export interface RoomType {
  id: string;
  name: string;
  category: string;
  tagline: string;
  priceEstimate: string;
  bedType: string;
  capacity: string;
  bathroom: string;
  features: string[];
  description: string;
  image: string;
  badge?: string;
}

export interface Attraction {
  id: string;
  name: string;
  category: 'waterfall' | 'themepark' | 'nature';
  distance: string;
  travelTime: string;
  description: string;
  image: string;
  travelTip: string;
  highlight: string;
}

export interface DishGroup {
  category: string;
  items: string[];
}

export interface DiningSpot {
  name: string;
  distance: string;
  type: string;
  specialty: string;
  timing: string;
  bestTimeToVisit?: string;
  rating?: string;
  reviewCount?: string;
  description: string;
  recommendedDishes: string[];
  dishGroups?: DishGroup[];
  isWalkable: boolean;
  image?: string;
  mapsUrl?: string;
}

export const HOTEL_INFO = {
  name: 'Crown Tourist Home',
  website: 'https://crowntouristhome.com',
  domain: 'crowntouristhome.com',
  locationTag: 'Athirappilly Road, Pariyaram, Kerala',
  tagline: 'Simple, Spotless & Budget-Friendly Stay on the Scenic Road to Athirappilly',
  address: 'Poovathingal, Chalakudy - Anamala Rd, Pariyaram, Keralam 680721, India',
  plusCode: '899H+JM Pariyaram, Keralam, India',
  managerPhone: '+91 80780 81022',
  managerPhoneRaw: '+918078081022',
  managerPhoneDisplay: '+91 80780 81022',
  phonePrimary: '+91 80780 81022',
  phoneDisplay: '+91 80780 81022',
  whatsappNumber: '918129646522',
  whatsappDisplay: '+91 81296 46522',
  googleMapsUrl: 'https://maps.app.goo.gl/Fsn2SShR5fRS5y9f8',
  heroImage: '/assets/aistudio/Crown_Tourist_Home_Entrance_725f6b0e.png',
  heroImageDusk: '/assets/aistudio/Crown_Tourist_Home_at_Dusk_77e290a6.png',
  heroSlides: HERO_SLIDES,
  entranceImage: '/assets/aistudio/Crown_Tourist_Home_Entrance_725f6b0e.png',
  heroCaption: 'Chalakudy - Anamala Road, Poovathingal',
  coordinates: {
    lat: 10.3190184,
    lng: 76.3743172,
  },
  timings: {
    checkInDefault: '12:00 PM',
    checkOutDefault: '12:00 PM',
    flexibilityNote: 'Flexible check-in and check-out upon coordination with manager for early morning arrivals or late departures.',
  },
  payments: ['Google Pay (UPI)', 'Direct Cash'],
  managerName: 'Friendly Host & On-Site Team',
};

export const ROOMS: RoomType[] = [
  {
    id: 'standard-double-non-ac',
    name: 'Standard Double Room (Non-AC)',
    category: 'Double Bed',
    tagline: 'Spotless room with fresh linens and attached clean washroom',
    priceEstimate: '₹700 – ₹900 / night',
    bedType: '1 Double Bed (Comfortable Foam Mattress)',
    capacity: '2 Persons',
    bathroom: 'Private Attached Bathroom (Tiled with Shower & 24/7 Water)',
    features: [
      'Freshly washed & changed bedsheets for each guest',
      'Clean attached private washroom with bucket/shower',
      'High-speed ceiling fan & cross-ventilation windows',
      'Sanitized tiled floors',
      '24/7 CCTV surveillance on corridors & parking',
      'Direct highway roadside access',
    ],
    description:
      'A tidy, well-ventilated room with guaranteed fresh bed linen and a sanitized private bathroom on the Athirappilly highway.',
    image: '/assets/aistudio/Compact_Blue-Striped_Guest_Room_c4f76418.png',
    badge: 'Popular Choice',
  },
  {
    id: 'deluxe-double-ac',
    name: 'Deluxe AC Double Room',
    category: 'Air Conditioned',
    tagline: 'Cool comfort with attached clean washroom and fresh linens',
    priceEstimate: '₹1,200 – ₹1,500 / night',
    bedType: '1 Double Bed (Comfortable Foam Mattress)',
    capacity: '2 Persons (+1 on request)',
    bathroom: 'Attached Clean Tiled Washroom with Mirror & Running Water',
    features: [
      'Efficient Air Conditioning (AC) + High-speed fan',
      'Fresh crisp bed linen washed before every check-in',
      'Attached clean tiled bathroom with private door',
      'Luggage desk and clothes rack hooks',
      'Secure lock and 24/7 premises CCTV',
      'Free parking space for cars & bikes',
    ],
    description:
      'Offers air-conditioned comfort near Dream World and Athirappilly Waterfalls. Spotlessly maintained with clean double bed, laundered white linens, private attached washroom, and quiet ambiance.',
    image: '/assets/aistudio/Tidy_Bedroom_with_En-Suite_Bathroom_c60cb533.png',
    badge: 'Air Conditioned',
  },
  {
    id: 'triple-three-bed',
    name: 'Spacious Triple Room (3-4 Persons)',
    category: 'Triple Bed',
    tagline: 'Budget-friendly space with 1 Double Bed + 1 Single Bed',
    priceEstimate: '₹1,400 – ₹1,800 / night',
    bedType: '1 Double Bed + 1 Single Bed',
    capacity: '3 – 4 Persons',
    bathroom: 'Spacious Attached Private Washroom',
    features: [
      'Ample space for 3 to 4 persons',
      'Freshly laundered linens and sanitized pillow covers',
      'Tiled attached washroom with regular supply',
      'Multiple charging points for phones & cameras',
      'CCTV monitored parking for vehicles right in front',
      'Flexible check-in coordination with manager',
    ],
    description:
      'Generously spaced room with 1 double bed and 1 single bed, attached clean washroom, and fresh linens for 3 to 4 persons. Clean, safe, and comfortable with zero unnecessary frills.',
    image: '/src/assets/images/crown_room_clean_bed_1792966713743.jpg',
  },
];

export const NEARBY_ATTRACTIONS: Attraction[] = [
  {
    id: 'chalakudy-river',
    name: 'Chalakudy River & Scenic View',
    category: 'nature',
    distance: 'Right next to hotel (50 m)',
    travelTime: '1 min walk',
    description:
      'The beautiful Chalakudy River flows right beside Crown Tourist Home. Guests can enjoy soothing water views, refreshing river breezes, and a peaceful natural setting just steps from the hotel rooms.',
    image: '/src/assets/images/crown_thumboormuzhi_hanging_bridge_1792966715603.jpg',
    travelTip: 'Perfect for morning walks, quiet sunset views, and soaking in the tranquil river ambiance right next door.',
    highlight: 'Flows right next to hotel · Scenic river view',
  },
  {
    id: 'athirappilly-falls',
    name: 'Athirappilly Waterfalls',
    category: 'waterfall',
    distance: '17 km',
    travelTime: '25 min drive',
    description:
      'Kerala’s most celebrated natural landmark, known as the "Niagara of India". An 80-foot majestic cascade framed by lush Western Ghats rainforest.',
    image: '/src/assets/images/crown_athirappilly_falls_1792966714993.jpg',
    travelTip: 'Visit early morning (8:30 AM to 11:00 AM) or after 3:30 PM for lesser crowds and cooler forest breezes.',
    highlight: 'Iconic 80-foot waterfall cascade',
  },
  {
    id: 'thumboormuzhi-bridge',
    name: 'Thumboormuzhi Dam & Hanging Bridge',
    category: 'nature',
    distance: '8.5 km',
    travelTime: '12 min drive',
    description:
      'A picturesque check-dam with an iconic pedestrian suspension hanging bridge across the Chalakudy River, accompanied by a vibrant butterfly garden and river park.',
    image: '/src/assets/images/crown_thumboormuzhi_hanging_bridge_1792966715603.jpg',
    travelTip: 'Walk across the bridge to reach Ezhattumugham Nature Village on the opposite riverbank.',
    highlight: 'Scenic suspension bridge & river views',
  },
  {
    id: 'dream-world',
    name: 'Dream World Water Theme Park',
    category: 'themepark',
    distance: '3.5 km',
    travelTime: '5 min drive',
    description:
      'A sprawling family water and amusement park located right along Athirappilly Road with thrilling water rides, wave pool, and rain dance.',
    image: '/src/assets/images/dream_world_clean_park_1793011864360.jpg',
    travelTip: 'Ideal morning activity before checking into Crown Tourist Home for a relaxing evening.',
    highlight: 'Right up the road from the hotel',
  },
  {
    id: 'silver-storm',
    name: 'Silver Storm Water Theme Park & Snow Storm',
    category: 'themepark',
    distance: '7 km',
    travelTime: '10 min drive',
    description:
      'Another top amusement hub featuring high-thrill roller rides, water slides, and the sub-zero indoor Snow Storm experience.',
    image: '/src/assets/images/silver_storm_water_park_1792968249034.jpg',
    travelTip: 'Great choice for kids and groups looking for full-day amusement park fun.',
    highlight: 'Water rides and sub-zero snow dome',
  },
  {
    id: 'vazhachal-charpa',
    name: 'Charpa & Vazhachal Waterfalls',
    category: 'waterfall',
    distance: '21 km',
    travelTime: '32 min drive',
    description:
      'Further up into the pristine Sholayar forest corridor past Athirappilly, offering gushing roadside falls at Charpa and the rapid cascade of Vazhachal.',
    image: '/src/assets/images/vazhachal_charpa_falls_1792968363728.jpg',
    travelTip: 'Requires Athirappilly check-post forest entry pass (valid for both Athirappilly and Vazhachal).',
    highlight: 'Deep rainforest & natural rapids',
  },
];

export const DINING_HIGHLIGHTS: DiningSpot[] = [
  {
    name: "Vasuvettan's Kada (Vasuvettante Kada)",
    distance: '2.8 km (approx. 5-6 min drive / quick auto ride)',
    type: 'Legendary Rustic Kerala Meals & Non-Veg Landmark',
    specialty: 'Authentic Banana Leaf Noon Meals, Signature Beef Fry, Prawns & Fresh River Fish',
    timing: '11:30 AM – 5:00 PM (Daily, or until sold out)',
    bestTimeToVisit: '11:30 AM – 1:00 PM (Arrive early to avoid heavy lunch crowds and guarantee signature specials)',
    rating: '4.5 ★',
    reviewCount: '6,616+ Google Reviews',
    description:
      'With an outstanding 4.5 rating from over 6,616 Google reviews, Vasuvettan’s Kada is a celebrated gastronomic icon on the Chalakudy - Athirappilly road. Highly sought-after by travelers and locals alike for serving piping hot Kerala noon meals on fresh banana leaves alongside tender spicy beef fry, rich prawns paal curry, crispy fish fry, and country duck roast at very budget-friendly rates.',
    recommendedDishes: [
      'Nadan Beef Fry (Must-order signature slow-roasted with coconut)',
      'Chemmeen Paal Curry (Creamy coconut-milk prawns delicacy)',
      'Crispy Fresh River Fish Fry & Fish Pollichathu',
      'Chemmeen Roast / Prawns Masala Fry',
      'Angamaly Mango Pulissery (Mambazha Pulissery) over Matta Rice',
      'Nadan Duck Curry & Country Chicken Varutharachathu',
    ],
    dishGroups: [
      {
        category: 'Signature Beef & Meat Highlights',
        items: [
          'Nadan Beef Fry: Tender chunks slow-roasted with coconut chips, curry leaves, and freshly ground pepper & garam masala.',
          'Nadan Duck Roast / Curry: Robust, deeply flavorful village-style duck gravy that pairs perfectly with hot rice.',
          'Country Chicken (Nadan Kozhi): Prepared in roasted coconut gravy (varutharacha curry).',
          'Traditional Pork Roast / Fry: Spiced in authentic central Kerala rustic fashion.',
        ],
      },
      {
        category: 'Prawns (Chemmeen) Delicacies',
        items: [
          'Chemmeen Paal Curry: Plump prawns gently stewed in a rich, velvety coconut milk curry—one of the highest rated items in customer reviews.',
          'Chemmeen Fry / Roast: Pan-roasted with spicy masala and crushed shallots.',
          'Unakka Chemmeen Chammanthi: Toasted dry prawn chutney served as an accompaniment with the meal.',
        ],
      },
      {
        category: 'Fresh River & Sea Fish Specials',
        items: [
          'Fish Fry (Karimeen / Neymeen / Ayala / Avoli): Marinated in crushed chili, turmeric, and lime, fried crispy to order.',
          'Fish Pollichathu: Fish coated in aromatic shallot-tomato masala wrapped and pan-grilled in banana leaves.',
          'Meen Mulakittathu: Fiery, tangy red fish curry simmered in traditional earthen clay pots (meen chatti).',
          'Meen Mutta (Seasonal): Rare and delicious spiced fish roe fry when available.',
        ],
      },
      {
        category: 'The Authentic Banana Leaf Noon Oonu',
        items: [
          'Steaming hot Kerala red matta rice served fresh on green banana leaves.',
          'Angamaly Mango Pulissery (sweet and tangy ripe mango curd curry).',
          'Traditional Moru curry, hot sambar, rasam, avial, cabbage thoran, puli inji (ginger-tamarind pickle), and crispy pappadam.',
        ],
      },
    ],
    isWalkable: false,
    image: '/src/assets/images/crown_kerala_meal_vasuettan_1792966716121.jpg',
    mapsUrl: 'https://maps.app.goo.gl/hVcazYyZhVDdk5Hd7',
  },
  {
    name: 'Local Tea Stalls & Chaya Kadas',
    distance: '100m - 200m (1-2 min walk)',
    type: 'Morning Breakfast & Evening Snacks',
    specialty: 'Hot Meter Chaya, Pazhampori, Appam & Egg Roast',
    timing: '6:30 AM – 9:00 PM',
    description:
      'Authentic Kerala tea shops right by the road where you can enjoy piping hot cardamom tea, fresh golden banana fritters (pazhampori), hot parotta with beef or chicken roast, and soft appam with vegetable stew.',
    recommendedDishes: [
      'Kerala Strong Chaya (Frothy Milk Tea)',
      'Crispy Hot Pazhampori (Banana Fritters)',
      'Flaky Kerala Porotta with Chicken / Beef Roast',
      'Appam with Egg Curry or Veg Kurma',
    ],
    isWalkable: true,
  },
  {
    name: 'Family Highway Multi-Cuisine Restaurants',
    distance: '500m - 1.5 km',
    type: 'Family Dining & Dinner',
    specialty: 'Biryani, Chinese, South Indian & North Indian Curries',
    timing: '11:00 AM – 10:30 PM',
    description:
      'Multiple well-reviewed family restaurants along the Athirappilly highway offering comfortable indoor seating, AC dining, tandoor items, Thalassery biryani, fried rice, and fresh juices for evening dinners.',
    recommendedDishes: [
      'Kerala Thalassery Dum Biryani',
      'Tandoori Chicken & Butter Naan',
      'Fresh Lime Soda & Seasonal Fruit Shakes',
    ],
    isWalkable: false,
  },
];

export const HOUSE_POLICIES = [
  {
    title: 'Clean Rooms & Fresh Sheets Guarantee',
    description:
      'We take hygiene seriously. Bed sheets and pillow covers are freshly changed and laundered after every single guest checkout. Rooms and bathrooms are washed and swept before every new arrival.',
  },
  {
    title: 'Bed & Attached Washroom Only (No Food In-House)',
    description:
      'We operate transparently as a tourist home focusing on clean, budget-friendly sleeping accommodation with private attached bathrooms. We do not operate an in-house restaurant, but famous local eateries (including Vasuettans Kada) are just a short stroll away.',
  },
  {
    title: 'Flexible Check-in & Check-out',
    description:
      'Standard check-in is 2:00 PM and check-out is 11:00 AM. However, we are not overly rigid! If you are arriving early in the morning by train/bus or want an evening departure, simply inform the manager in advance and we accommodate subject to room availability.',
  },
  {
    title: '24/7 CCTV & Friendly On-Site Manager',
    description:
      'Our friendly manager and support staff stay on the property to guide you with local routes, bus timings, and sightseeing tips. The premises and parking areas are monitored by 24-hour CCTV for your peace of mind.',
  },
  {
    title: 'Simple Direct Payments (Google Pay / Cash)',
    description:
      'Pay conveniently on arrival via Google Pay (GPay) or direct cash. No hidden booking service fees, credit card surcharges, or foreign platform markups.',
  },
];

export const FAQS = [
  {
    q: 'How do I book a room at Crown Tourist Home?',
    a: 'We do not use complicated online OTA booking engines. Simply click "Book via WhatsApp" (+91 81296 46522) or give the manager a direct phone call (+91 80780 81022). You can confirm your dates, room choice, and get immediate confirmation with no booking commissions.',
  },
  {
    q: 'What is the check-in and check-out time?',
    a: 'Standard check-in time is 12:00 PM and check-out time is 12:00 PM. However, we offer flexibility! If you arrive earlier from an overnight train or need extended check-out, simply inform the manager in advance and we will accommodate based on room availability.',
  },
  {
    q: 'Is food available inside the hotel?',
    a: 'We do not run an in-house kitchen or room service. Instead, we are located right near authentic local eateries, including the famous Vasuettans Kada (legendary Kerala banana leaf meals & fish fry, 3-4 min walk) and local tea stalls for breakfast and snacks.',
  },
  {
    q: 'Are the rooms and bathrooms clean?',
    a: 'Yes, 100%. We guarantee that bedsheets and linens are replaced after each guest, and floors and attached washrooms are thoroughly scrubbed and sanitized before you check in.',
  },
  {
    q: 'Is there parking for cars and bikes?',
    a: 'Yes, there is dedicated open parking space directly in front of the tourist home, monitored 24/7 by CCTV security cameras.',
  },
  {
    q: 'How far is Crown Tourist Home from Athirappilly Waterfalls?',
    a: 'We are situated on Athirappilly Road in Pariyaram. It takes approximately 20 to 25 minutes (about 17 km) of scenic driving through green hills and forests to reach Athirappilly Falls.',
  },
  {
    q: 'How far is Crown Tourist Home from Chalakudy Railway Station and Cochin Airport?',
    a: 'Chalakudy Railway Station (CKI) is just 8 km away (approx. 12-15 minutes drive / quick auto ride). Cochin International Airport (COK) is 28 km away (approx. 35-40 minutes drive via NH 544). Frequent buses and taxis connect directly to Pariyaram.',
  },
  {
    q: 'Is the Chalakudy River close to the hotel?',
    a: 'Yes, the Chalakudy River flows right next to Crown Tourist Home. Guests can enjoy scenic water views, soothing river breezes, and calm walks right beside the property.',
  },
  {
    q: 'What payment modes are accepted?',
    a: 'We accept Google Pay (GPay / UPI) and Cash upon arrival.',
  },
];
