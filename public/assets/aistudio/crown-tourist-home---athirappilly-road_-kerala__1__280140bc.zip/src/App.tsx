/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { RoomsSection } from './components/RoomsSection';
import { DiningSpotlight } from './components/DiningSpotlight';
import { NearbyExplorer } from './components/NearbyExplorer';
import { HousePolicySection } from './components/HousePolicySection';
import { LocationDirections } from './components/LocationDirections';
import { GuestReviewsAndFAQ } from './components/GuestReviewsAndFAQ';
import { Footer } from './components/Footer';
import { BookingModal } from './components/BookingModal';
import { FloatingActionBar } from './components/FloatingActionBar';

export default function App() {
  const [bookingModalOpen, setBookingModalOpen] = useState(false);
  const [selectedRoomId, setSelectedRoomId] = useState<string | undefined>(undefined);
  const [selectedDates, setSelectedDates] = useState<
    { checkIn: string; checkOut: string; guests: string; kids?: string } | undefined
  >(undefined);

  const handleOpenBooking = (
    roomId?: string,
    dates?: { checkIn: string; checkOut: string; guests: string; kids?: string }
  ) => {
    setSelectedRoomId(roomId);
    if (dates) {
      setSelectedDates(dates);
    }
    setBookingModalOpen(true);
  };

  const handleCloseBooking = () => {
    setBookingModalOpen(false);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF8F5] text-[#242424] overflow-x-hidden w-full">
      {/* Top Bar Contract Compliant Header */}
      <Navbar onOpenBooking={() => handleOpenBooking()} />

      <main className="flex-1">
        {/* Editorial Hero with high-fidelity exterior image and quick inquiry bar */}
        <Hero onOpenBooking={handleOpenBooking} />

        {/* Room showcase & honest budget tariffs */}
        <RoomsSection onOpenBooking={handleOpenBooking} />

        {/* Dedicated Local Food Spotlight: Vasuettans Kada & tea stalls */}
        <DiningSpotlight />

        {/* Athirappilly sightseeing corridor interactive guide (Solenne inspired) */}
        <NearbyExplorer />

        {/* House Policy & Cleanliness Standard */}
        <HousePolicySection />

        {/* Interactive Location, Plus Code copy & Transit directions */}
        <LocationDirections />

        {/* Guest Reviews & FAQ */}
        <GuestReviewsAndFAQ onOpenBooking={() => handleOpenBooking()} />
      </main>

      {/* Quiet Footer */}
      <Footer onOpenBooking={() => handleOpenBooking()} />

      {/* Floating Action Button for instant WhatsApp / Call */}
      <FloatingActionBar onOpenBooking={() => handleOpenBooking()} />

      {/* Direct Booking Modal with pre-filled WhatsApp link generator */}
      <BookingModal
        isOpen={bookingModalOpen}
        onClose={handleCloseBooking}
        initialRoomId={selectedRoomId}
        initialDates={selectedDates}
      />
    </div>
  );
}
